Sorting, Searching, and Counting
================================

.. autofunction:: cupy.argmax
.. autofunction:: cupy.argmin
.. autofunction:: cupy.count_nonzero
.. autofunction:: cupy.nonzero
.. autofunction:: cupy.flatnonzero
.. autofunction:: cupy.where
