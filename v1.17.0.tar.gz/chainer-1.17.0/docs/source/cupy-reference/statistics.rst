Statistics
==========

Order statistics
----------------

.. autofunction:: cupy.amin
.. autofunction:: cupy.amax


Means and variances
-------------------

.. autofunction:: cupy.mean
.. autofunction:: cupy.var
.. autofunction:: cupy.std


Histograms
----------

.. autofunction:: cupy.bincount
