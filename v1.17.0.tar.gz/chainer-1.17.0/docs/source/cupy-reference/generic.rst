NumPy-CuPy Generic Code Support
===============================

.. autofunction:: cupy.get_array_module
