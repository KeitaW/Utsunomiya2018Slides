Indexing Routines
=================

.. autofunction:: cupy.take
.. autofunction:: cupy.diagonal
.. autofunction:: cupy.ix_
.. autofunction:: cupy.fill_diagonal
