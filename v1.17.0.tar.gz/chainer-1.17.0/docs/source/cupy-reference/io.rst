Input and Output
================

NPZ files
---------

.. autofunction:: cupy.load
.. autofunction:: cupy.save
.. autofunction:: cupy.savez
.. autofunction:: cupy.savez_compressed


String formatting
-----------------

.. autofunction:: cupy.array_repr
.. autofunction:: cupy.array_str
