--------------------
Core functionalities
--------------------

.. currentmodule:: chainer
.. toctree::
   :maxdepth: 1

   core/variable
   core/flag
   core/function
   core/link
   core/optimizer
   core/serializer
   core/dataset
   core/training
   core/debug
   core/function_set
