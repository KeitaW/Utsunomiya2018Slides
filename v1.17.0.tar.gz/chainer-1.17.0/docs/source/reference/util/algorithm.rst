Common algorithms
-----------------
.. automodule:: chainer.utils

.. autoclass:: WalkerAlias
   :members: sample, to_gpu
