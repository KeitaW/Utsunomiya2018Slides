FunctionSet (deprecated)
------------------------

.. currentmodule:: chainer
.. autoclass:: FunctionSet
   :members:
