Variable
--------

.. currentmodule:: chainer
.. autoclass:: Variable
   :members:
