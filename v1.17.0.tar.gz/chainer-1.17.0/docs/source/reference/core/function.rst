Function
--------

.. currentmodule:: chainer
.. autoclass:: Function
   :members:

.. autofunction:: force_backprop_mode
.. autofunction:: no_backprop_mode
