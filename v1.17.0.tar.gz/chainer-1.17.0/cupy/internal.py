def prod(args, init=1):
    for arg in args:
        init *= arg
    return init
